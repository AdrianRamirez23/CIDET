export class Municipios{
    id:  number;
    Nombre: string;
    Departamento: string;
    CodigoDANE: string;
    DistritoCapital: string;

}