export class Departamentos{
    CodigoDepartamento: string;
    NombreDepartamento: string;
}