import { Injectable } from '@angular/core';
import { Departamentos } from '../models/departamentos';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class DepartamentosService {
  myApiURL='https://localhost:44345/';
  ApiURL='api/Departamentos/';
  list: Departamentos[];
  constructor(private http: HttpClient) { }

  ListaDepartamentos(){
    this.http.get(this.myApiURL+this.ApiURL).toPromise()
                   .then(data =>{
                     this.list=data as Departamentos[];
                   });
  }
}
