import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Municipios } from '../models/municipios';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MunicipiosService {
  myApiURL='https://localhost:44345/';
  ApiURL='api/Municipios/';
  list: Municipios[];
  municipio: Municipios;
  private actualizarFormulario= new BehaviorSubject<Municipios>({} as any);
  constructor(private http: HttpClient) { }

  CrearMunicipio(municipio: Municipios): Observable<Municipios>{
    return this.http.post<Municipios>(this.myApiURL+this.ApiURL,municipio);
  }
  ListaMunicipios(){
    this.http.get(this.myApiURL+this.ApiURL).toPromise()
                   .then(data =>{
                     this.list=data as Municipios[];
                   });
  }
  eliminarMunicipio(id:number):Observable<Municipios>{
    return this.http.delete<Municipios>(this.myApiURL+this.ApiURL+id);
  }
  actualizarMunicipio(municipio){
    this.actualizarFormulario.next(municipio);
  }
  obtenerMunicipio():Observable<Municipios>{
    return this.actualizarFormulario.asObservable();
  }
  editarMunicipio(municipio: Municipios):Observable<Municipios>{
    return this.http.put<Municipios>(this.myApiURL+this.ApiURL,municipio);
  }
}
