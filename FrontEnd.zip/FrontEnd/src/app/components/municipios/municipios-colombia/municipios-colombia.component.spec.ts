import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MunicipiosColombiaComponent } from './municipios-colombia.component';

describe('MunicipiosColombiaComponent', () => {
  let component: MunicipiosColombiaComponent;
  let fixture: ComponentFixture<MunicipiosColombiaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MunicipiosColombiaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MunicipiosColombiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
