import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Municipios } from 'src/app/models/municipios';
import { DepartamentosService } from 'src/app/services/departamentos.service';
import { MunicipiosService } from 'src/app/services/municipios.service';
import { Departamentos } from 'src/app/models/departamentos';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-municipios-colombia',
  templateUrl: './municipios-colombia.component.html',
  styleUrls: ['./municipios-colombia.component.css']
})
export class MunicipiosColombiaComponent implements OnInit, OnDestroy {
  formTask: FormGroup;
  suscription: Subscription;
  municipio: Municipios;
  idMunicipio=0;
  constructor(private formBuilder: FormBuilder, 
              private municipioService: MunicipiosService,
              private toastr: ToastrService,
              public departamentosService: DepartamentosService
              ) { 
   this.formTask=this.formBuilder.group({
     nombre: ['',[Validators.required]],
     departamento: ['Seleccione Opción',[Validators.required]],
     codigoDANE:['',[Validators.required]],
     distritoCapital: ['Seleccione Opción',[Validators.required]]
   })
  }

  ngOnInit(): void {
    this.departamentosService.ListaDepartamentos();
    this.suscription= this.municipioService.obtenerMunicipio().subscribe(data =>{
      console.log(data);
      this.municipio=data;
      this.formTask.patchValue({
         nombre: this.municipio.Nombre,
         departamento: this.municipio.Departamento,
         codigoDANE:this.municipio.CodigoDANE,
         distritoCapital:this.municipio.DistritoCapital
      });
      this.idMunicipio=this.municipio.id;
    });
  }
  ngOnDestroy(){
    this.suscription.unsubscribe();
  }
  CrearMunicipio(){
    if(this.idMunicipio===0){
      const municipio: Municipios={
        id:0,
        Nombre: this.formTask.get('nombre')?.value,
        Departamento: this.formTask.get('departamento')?.value,
        CodigoDANE: this.formTask.get('codigoDANE')?.value,
        DistritoCapital: this.formTask.get('distritoCapital')?.value,
      };
      this.municipioService.CrearMunicipio(municipio).subscribe(data =>{
        this.toastr.success('Registro Agregado','El municipio fue creado correctamente');
        this.municipioService.ListaMunicipios();
        this.formTask.reset();
      });
    }else{
      const municipio: Municipios={
        id:this.idMunicipio,
        Nombre: this.formTask.get('nombre')?.value,
        Departamento: this.formTask.get('departamento')?.value,
        CodigoDANE: this.formTask.get('codigoDANE')?.value,
        DistritoCapital: this.formTask.get('distritoCapital')?.value,
      };
      this.municipioService.editarMunicipio(municipio).subscribe(data =>{
        this.toastr.info('Registro Editado','El municipio fue editado correctamente');
        this.municipioService.ListaMunicipios();
        this.formTask.reset();
        this.idMunicipio=0;
      });
    }
     
  }

}
