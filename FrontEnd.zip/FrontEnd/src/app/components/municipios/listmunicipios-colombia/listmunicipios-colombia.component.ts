import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Municipios } from 'src/app/models/municipios';
import { MunicipiosService } from 'src/app/services/municipios.service';

@Component({
  selector: 'app-listmunicipios-colombia',
  templateUrl: './listmunicipios-colombia.component.html',
  styleUrls: ['./listmunicipios-colombia.component.css']
})
export class ListmunicipiosColombiaComponent implements OnInit {

  constructor(public municipioService: MunicipiosService,           
              public toastr: ToastrService) { }

  ngOnInit(): void {
    this.municipioService.ListaMunicipios();
    
  }
  eliminarMunicipio(id: number){
    if(confirm('Esta seguro que desea eliminar el registro?')){
      this.municipioService.eliminarMunicipio(id).subscribe(data =>{
         this.toastr.warning('Registro Eliminado','El municipio fue eliminado');
         this.municipioService.ListaMunicipios();
      });
    }
  }
  editar(municipio){
    this.municipioService.actualizarMunicipio(municipio);
  }
 

}
