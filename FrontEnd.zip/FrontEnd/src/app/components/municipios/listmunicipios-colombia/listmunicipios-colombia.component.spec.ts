import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListmunicipiosColombiaComponent } from './listmunicipios-colombia.component';

describe('ListmunicipiosColombiaComponent', () => {
  let component: ListmunicipiosColombiaComponent;
  let fixture: ComponentFixture<ListmunicipiosColombiaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListmunicipiosColombiaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListmunicipiosColombiaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
